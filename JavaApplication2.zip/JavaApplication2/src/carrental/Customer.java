package carrental;

public class Customer {
    private String ID;
    private String name;

    public Customer(String id, String name) {
        this.ID = ID;
        this.name = name;
    }

    @Override
    public String toString() {
        return ID + " - " + name;
    }
}
