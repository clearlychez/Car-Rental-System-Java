package carrental;

public class Main {
    public static void main(String[] args) {
        RentalAgency agency = new RentalAgency();

        Car car1 = new Car("C001", "Toyota Corolla");
        Car car2 = new Car("C002", "Honda Civic");

        Customer cust1 = new Customer("U001", "Cyrene");

        agency.addCar(car1);
        agency.addCar(car2);
        agency.addCustomer(cust1);

        System.out.println("=== Available Cars ===");
        agency.listCars();

        System.out.println("\n=== Renting Car C001 ===");
        agency.rentCar("C001", "U001");
        agency.listCars();

        System.out.println("\n=== Returning Car C001 ===");
        agency.returnCar("C001");
        agency.listCars();
    }
}
