package carrental;

public class Car {
    private String id;
    private String model;
    private boolean available;

    public Car(String id, String model) {
        this.id = id;
        this.model = model;
        this.available = true;
    }

    public boolean isAvailable() {
        return available;
    }

    public void rentCar() {
        if (available) {
            available = false;
            System.out.println("Car " + id + " rented successfully!");
        } else {
            System.out.println("Car " + id + " is not available.");
        }
    }

    public void returnCar() {
        available = true;
        System.out.println("Car " + id + " returned successfully!");
    }

    @Override
    public String toString() {
        return id + " - " + model + " (Available: " + available + ")";
    }
}
