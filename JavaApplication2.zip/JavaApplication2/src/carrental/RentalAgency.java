package carrental;

import java.util.*;

public class RentalAgency {
    private List<Car> cars = new ArrayList<>();
    private List<Customer> customers = new ArrayList<>();

    public void addCar(Car car) {
        cars.add(car);
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public void rentCar(String carId, String customerId) {
        Car car = cars.stream()
                      .filter(c -> c.toString().contains(carId))
                      .findFirst()
                      .orElse(null);

        if (car != null && car.isAvailable()) {
            car.rentCar();
            System.out.println("Customer " + customerId + " rented car " + carId);
        } else {
            System.out.println("Car not available.");
        }
    }

    public void returnCar(String carId) {
        Car car = cars.stream()
                      .filter(c -> c.toString().contains(carId))
                      .findFirst()
                      .orElse(null);

        if (car != null) {
            car.returnCar();
        }
    }

    public void listCars() {
        cars.forEach(System.out::println);
    }
}
