package login;

import java.util.Scanner;

public class LoginSystem {
    public static void main(String[] args) {
        String correctUsername = "Cyrene01";
        String correctPassword = "12345";
        int attempts = 3;

        Scanner sc = new Scanner(System.in);

        while (attempts > 0) {
            System.out.print("Enter username\n: ");
            String username = sc.nextLine();

            System.out.print("Enter password\n: ");
            String password = "";
            char[] chars = sc.nextLine().toCharArray();

            // Mask password with *
            for (int i = 0; i < chars.length; i++) {
                password += chars[i];
                System.out.print("*");
            }
            System.out.println();

            if (username.equals(correctUsername) && password.equals(correctPassword)) {
                System.out.println("Login successful");
                break;
            } else {
                attempts--;
                System.out.println("Incorrect credentials. Attempts left: " + attempts);
            }
        }

        if (attempts == 0) {
            System.out.println("Access denied! Too many failed attempts.");
        }

        sc.close();
    }
}
